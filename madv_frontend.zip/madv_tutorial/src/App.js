import "./App.css";
import SetForm from '../src/form/SetForm';

function App() {
  return <div>
    <SetForm />
  </div>;
}

export default App;
