package com.madv.madv_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MadvProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MadvProjectApplication.class, args);
	}

}
