package com.madv.madv_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadvProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
